from sqlalchemy import select, outerjoin, union, join, Table, Column, Integer, String
from . import CastSchema, ObjectQuery, create_postgres_engine, create_oracle_engine
from .internal.reflect import reflect_table
from .internal.p1 import get_message # @UnresolvedImport
from .server import Server
from cast.application import create_sqlserver_engine
from distutils.version import StrictVersion
 

class ManagmentBase(CastSchema):
    """
    A connection to a management base
    """

#     @todo : 
#     
#     - do not do the same mistake twice...
#       - table loading should be delayed up to usefull...
#     - try on a sqlserver case sensitive
# 
#     Miscelaneous information 
#     
#     cms_dynamicfields contains uuids it seems to be 
#     - uuid.uuid4()
    
    def __init__(self, name, engine=None):
        
        CastSchema.__init__(self, name, engine)
        self._package_name = "PMC_MAIN"
        
        """
        Interesting tables :
        - application
        - module
        - synchronisation translation
        """
        self.cms_dynamicfields = reflect_table("cms_dynamicfields", self.metadata, self.engine)
        
        self.cms_objectlinks = reflect_table("cms_objectlinks", self.metadata, self.engine)
        
        self.cms_sync_translation = reflect_table("cms_sync_translation", self.metadata, self.engine)

        
        self.cms_portf_application = reflect_table("cms_portf_application", self.metadata, self.engine)
    
        self.cms_portf_module = reflect_table("cms_portf_module", self.metadata, self.engine)

        self.cms_inf_snapshot = reflect_table("cms_inf_snapshot", self.metadata, self.engine) 

        self.cms_portf_system = reflect_table("cms_portf_system", self.metadata, self.engine) 
    
    
        # infrastructure
        self.cms_inf_css_centraldb = reflect_table("cms_inf_css_centraldb", self.metadata, self.engine)
        self.cms_inf_css_localdb = reflect_table("cms_inf_css_localdb", self.metadata, self.engine)

        self.cms_inf_ora_centraldb = reflect_table("cms_inf_ora_centraldb", self.metadata, self.engine)
        self.cms_inf_ora_localdb = reflect_table("cms_inf_ora_localdb", self.metadata, self.engine)

        self.cms_inf_sqlsrv_centraldb = reflect_table("cms_inf_sqlsrv_centraldb", self.metadata, self.engine)
        self.cms_inf_sqlsrv_localdb = reflect_table("cms_inf_sqlsrv_localdb", self.metadata, self.engine)

    
        # connections
        self.cms_inf_store_css = reflect_table("cms_inf_store_css", self.metadata, self.engine)
        
        self.cms_inf_store_oracle = reflect_table("cms_inf_store_oracle", self.metadata, self.engine)
        self.cms_inf_ora_accesssid = reflect_table("cms_inf_ora_accesssid", self.metadata, self.engine)
        self.cms_inf_ora_accesssrv = reflect_table("cms_inf_ora_accesssrv", self.metadata, self.engine)
        
        self.cms_inf_store_sqlserver = reflect_table("cms_inf_store_sqlserver", self.metadata, self.engine)
        self.cms_inf_sqlsrv_accessinst = reflect_table("cms_inf_sqlsrv_accessinst", self.metadata, self.engine)
        self.cms_inf_sqlsrv_accessport = reflect_table("cms_inf_sqlsrv_accessport", self.metadata, self.engine)
        
        
        # delivery and deploy
        self.delivery_path = None
        self.deploy_path = None
        
        cms_pref_sources = reflect_table("cms_pref_sources", self.metadata, self.engine)  
        
        query = select([cms_pref_sources.c.serverpath, 
                        cms_pref_sources.c.deploypath])
        
        for line in self._execute_sqlalchemyquery(query):
            
            self.delivery_path = line[0]
            self.deploy_path = line[1]
        
    
    def __repr__(self):
        
        return "Managment(%s)" %self.name
        
    def get_applications(self):
        """
        Get the applications defined in the base.
        
        :rtype: list of :class:`cast.application.managment.Application`
        """
        
        table_join = self.cms_portf_application.join(self.cms_dynamicfields,
                                                     self.cms_portf_application.c.object_id == self.cms_dynamicfields.c.object_id)
        
        table_join = table_join.join(self.cms_sync_translation,
                                     self.cms_dynamicfields.c.field_value == self.cms_sync_translation.c.entryobjpmc)
        
        # may have several entries
        query = select([self.cms_portf_application.c.object_id, 
                        self.cms_portf_application.c.object_name, 
                        self.cms_portf_application.c.deploypath,
                        self.cms_dynamicfields.c.field_value,
                        self.cms_sync_translation.c.idobjservice,
                        self.cms_portf_application.c.localdb_id,
                        self.cms_portf_application.c.mail]).select_from(table_join).where(self.cms_sync_translation.c.adapterclass == 'com.castsoftware.pmc.connection.synchro.UserProjectOptionAdapter')
        
        result = []
        
        application_ids = set()
        
        for line in self._execute_sqlalchemyquery(query):
            
            if line[3].startswith('uuid'):
                
                if line[0] not in application_ids:
                    result.append(Application(self, line[0], line[1], line[2], line[3], line[4], line[5], line[6]))
                    application_ids.add(line[0])
        
        return result
        
    def get_application(self, name):
        """
        Access to an application by name.
        
        :param str name: the name of the application

        :rtype: :class:`cast.application.managment.Application`
        """
        for app in self.get_applications():
            if app.name == name:
                return app
            
        return None
    
    def get_delivery_path(self):
        """
        Access to delivery path.
        
        :rtype: str
        """
        return self.delivery_path
    
    def get_deploy_path(self):
        """
        Access to deploy path.

        :rtype: str
        """
        return self.deploy_path
    
    def _get_server_engine(self, server_id, server_type):
        """
        Find a server by id
        """
        if server_type == "css":
            
            query = select([self.cms_inf_store_css.c.host,
                            self.cms_inf_store_css.c.port,
                            self.cms_inf_store_css.c.username,
                            self.cms_inf_store_css.c.password]).where(self.cms_inf_store_css.c.object_id == server_id)
            
            for line in self._execute_sqlalchemyquery(query):           
                
                message = get_message(line[3][9:])
                return create_postgres_engine(line[2], message, line[0], line[1])
            
            
        elif server_type == "ora":
            # checked with 'service' name
            # @todo : check if working with SID
            _from = outerjoin(self.cms_inf_store_oracle, 
                              self.cms_inf_ora_accesssid, 
                              self.cms_inf_store_oracle.c.access_id == self.cms_inf_ora_accesssid.c.object_id)
            
            _from = outerjoin(_from,
                              self.cms_inf_ora_accesssrv,
                              self.cms_inf_store_oracle.c.access_id == self.cms_inf_ora_accesssrv.c.object_id)
            
            query = select([self.cms_inf_store_oracle.c.host,
                            self.cms_inf_store_oracle.c.port,
                            self.cms_inf_store_oracle.c.username,
                            self.cms_inf_store_oracle.c.password,
                            self.cms_inf_ora_accesssid.c.service,
                            self.cms_inf_ora_accesssrv.c.service]).select_from(_from).where(self.cms_inf_store_oracle.c.object_id == server_id)
                            
            for line in self._execute_sqlalchemyquery(query):           
                
                message = get_message(line[3][9:])
                return create_oracle_engine(line[2], message, line[0], line[1], line[4], line[5])

        elif server_type == "sqlsrv":
            # @todo
            # not working properly because of connection sqlserver needing 'schema'
            
#             raise RuntimeError('Why are you using sqlserver? Please use css instead.')
                        
            _from = outerjoin(self.cms_inf_store_sqlserver, 
                              self.cms_inf_sqlsrv_accessinst, 
                              self.cms_inf_store_sqlserver.c.access_id == self.cms_inf_sqlsrv_accessinst.c.object_id)
            
            _from = outerjoin(_from,
                              self.cms_inf_sqlsrv_accessport,
                              self.cms_inf_store_sqlserver.c.access_id == self.cms_inf_sqlsrv_accessport.c.object_id)
            
            query = select([self.cms_inf_store_sqlserver.c.host,
                            self.cms_inf_store_sqlserver.c.username,
                            self.cms_inf_store_sqlserver.c.password,
                            self.cms_inf_store_sqlserver.c.trusted,
                            self.cms_inf_sqlsrv_accessinst.c.instance,
                            self.cms_inf_sqlsrv_accessport.c.port]).select_from(_from).where(self.cms_inf_store_sqlserver.c.object_id == server_id)
                            
            for line in self._execute_sqlalchemyquery(query):           
                
                message = get_message(line[2][9:])
                return create_sqlserver_engine(line[1], message, line[0], '', line[5], line[4], line[3])
        
        
                


class Application:
    """
    The definition of an application in CMS
    """
    def __init__(self, mb, identifier, name, deploy_path, uuid, kb_id, local_mngt_id, mail):
        self.mb = mb
        self.id = identifier
        self.uuid = uuid
        self.name = name
        self.deploy_path = deploy_path
        self.kb_id = kb_id
        # the mngt id of the 'local service'
        self.local_mngt_id = local_mngt_id
        
        self.__mail = mail 
        # kb
        self.analysis_service = None
        
        # centrals
        self.dashboard_services = []
        
        # source code packages (repositories)
        self.packages = []
        

    def get_packages(self):
        """
        Get the source packages of the application.

        :rtype: list of :class:`cast.application.managment.Package`
        """
        return self.packages

    def get_analysis_units(self):
        """
        Get the analysis units of the application.

        :rtype: list of :class:`cast.application.managment.AnalysisUnit`
        """
        # source code repositories ids
        self.repositories_ids = self._calculate_repositories()
        self.analysis_units = self._calculate_analysis_units()
        return self.analysis_units

    def get_modules(self):
        """
        Access to modules definitions
        
        :rtype: list of :class:`cast.application.managment.Module`
        """
        self.modules = self._calculate_module_list()
        return self.modules
    
    def get_module(self, name):
        """
        Get a module definition

        :rtype: :class:`cast.application.managment.Module`
        """
        self.modules = self._calculate_module_list()
        for module in self.modules:
            if module.name == name:
                return module
            
        return None
    
    def get_snapshots(self):
        """
        Get the snapshots of the application.

        :rtype: list of :class:`cast.application.managment.Snapshot`
        """
        self.snapshots = self._calculate_snapshots()
        return self.snapshots

    def get_analysis_service(self):
        """
        Access to analysis service of the application
        
        :rtype: :class:`cast.application.KnoweldgeBase`
        """
        if not self.analysis_service:
            
            name = None
            server_id = None
            
            cursor = self.mb.create_cursor()

            self.mb._execute_raw_query(cursor, 
                                       """select object_name, server_id, server_type 
                                          from (      select object_id, object_name, server_id, 'css' as server_type from cms_inf_css_localdb 
                                                union select object_id, object_name, server_id, 'ora' as server_type from cms_inf_ora_localdb 
                                                union select object_id, object_name, server_id, 'sqlsvr' as server_type from cms_inf_sqlsrv_localdb) temp 
                                          where temp.object_id = (%s)""" % self.local_mngt_id)
            
            for line in cursor:
                name = line[0]
                server_id = line[1]
                server_type = line[2]
                
                engine = self.mb._get_server_engine(server_id, server_type)
                
                try:
                    self.analysis_service = Server.get_server(engine).get_schema(name)
                except:
                    # connection refused...
                    raise RuntimeError('Connection refused to %s' % str(engine))
            
        return self.analysis_service
        
    def get_dashboard_services(self):
        """
        Access to analysis service of the application

        :rtype: list of :class:`cast.application.central.CentralBase`
        """

        if not self.dashboard_services:
            
            # get the services id
            system_link = join(self.mb.cms_portf_system, 
                               self.mb.cms_objectlinks, 
                               self.mb.cms_portf_system.c.object_id == self.mb.cms_objectlinks.c.caller_id) 
            
            query = select([self.mb.cms_portf_system.c.central_id]).select_from(system_link)
            query = query.where(self.mb.cms_objectlinks.c.symbol == 'applications')
            query = query.where(self.mb.cms_objectlinks.c.callee_id == self.id)
            
            services_id = []
            
            for line in self.mb._execute_sqlalchemyquery(query):
                
                services_id.append(line[0])
                
            # locate them in centradb tables
            cursor = self.mb.create_cursor()

            self.mb._execute_raw_query(cursor, 
                                       """select object_name, server_id, server_type 
                                          from (      select object_id, object_name, server_id, 'css' as server_type from cms_inf_css_centraldb 
                                                union select object_id, object_name, server_id, 'ora' as server_type from cms_inf_ora_centraldb 
                                                union select object_id, object_name, server_id, 'sqlsvr' as server_type from cms_inf_sqlsrv_centraldb) temp 
                                          where temp.object_id in (%s)""" % ','.join([str(service_id) for service_id in services_id]))
            
            for line in cursor:
                name = line[0]
                server_id = line[1]
                server_type = line[2]

                engine = self.mb._get_server_engine(server_id, server_type)
                
                try:
                    self.dashboard_services.append(Server.get_server(engine).get_schema(name))
                except:
                    # connection refused...
                    print('connection refused')
                    pass
        
        return self.dashboard_services

    
    def get_email_to_send_reports(self):
        """
        If configured, returns the email to send reports to.
        
        :rtype: str
        """
        return self.__mail
        

        
    def _calculate_repositories(self):
        """
        CMS 'sources' folders than contains Analysis units
        """
        repository_types = ['bo', 'dbudb', 'dbzosextract', 'file', 'formsextract', 
                            'mfextract', 'oracleextract', 'sapextract', 'sqlserverextract',
                            'sybaseextract', 'uiextract']
    
        result = []
    
        for t in repository_types:
            
            try:
                    
                cursor = self.mb.create_cursor()
                self.mb._execute_raw_query(cursor, 'select object_id, object_name, rootpath from cms_code_repo_%s where application_id = %s' % (t,self.id))
                
                for line in cursor:
                    result.append(line[0])
                    self.packages.append(Package(line[0], line[1], line[2], t))
                    
            except:
                # no such techno
                pass
            
            
        return result
    
    def _calculate_analysis_units(self):
        
        technos = ['asp', 
                   'bo',
                   'cobol',
                   'cpp',
                   'forms',
                   'j2ee',
                   'net',
                   'ora',
                   'pb',
                   'sap',
                   'sqlsrv',
                   'syb',
                   'ua',
                   'udb',
                   'ui',
                   'vb',
                   'zos']

        result = []
        aus = {}
        for techno in technos:
            
            try:
                cursor = self.mb.create_cursor()

                self.mb._execute_raw_query(cursor, """
select au.object_id, object_name, execlog, execdate, field_value 
  from cms_%s_analysis au, cms_dynamicfields dyn 
 where resource_id in (%s) and au.object_id = dyn.object_id and dyn.field_value like 'uuid%%'""" % 
                                           (techno, ','.join(str(r) for r in self.repositories_ids)))
                
                for line in cursor:
                    
                    au = AnalysisUnit(self.mb, line[0], line[1], techno, self, line[2], line[3], line[4])
                    aus[line[0]] = au
                    result.append(au)
            except:
                # no such techno
                pass
                
        table_join = outerjoin(self.mb.cms_dynamicfields,
                               self.mb.cms_sync_translation,
                               self.mb.cms_dynamicfields.c.field_value == self.mb.cms_sync_translation.c.entryobjpmc)
        
        query = select([self.mb.cms_dynamicfields.c.object_id, self.mb.cms_sync_translation.c.object_id]).select_from(table_join).where(self.mb.cms_dynamicfields.c.object_id.in_(aus.keys()))
        
        for line in self.mb._execute_sqlalchemyquery(query):
            aus[line[0]].local_id_setnam = line[1]
        
        return result
        
    def _calculate_module_list(self):
        
        # list modules of app
        
        table_join = self.mb.cms_portf_module.join(self.mb.cms_dynamicfields, 
                                                   self.mb.cms_portf_module.c.object_id == self.mb.cms_dynamicfields.c.object_id,
                                                   isouter=True)
        
        query = select([self.mb.cms_portf_module.c.object_id, 
                        self.mb.cms_portf_module.c.object_name,
                        self.mb.cms_dynamicfields.c.field_value]).select_from(table_join).where(self.mb.cms_portf_module.c.application_id == self.id)
        
        
        result = []
        
        for line in self.mb._execute_sqlalchemyquery(query):
            
            result.append(Module(self.mb, line[0], line[1], line[2], self))

        return result
    
    def _calculate_snapshots(self):
        
        
        query = select([self.mb.cms_inf_snapshot.c.object_id,
                        self.mb.cms_inf_snapshot.c.object_name,
                        self.mb.cms_inf_snapshot.c.versionlabel,
                        self.mb.cms_inf_snapshot.c.functionaldate,
                        self.mb.cms_inf_snapshot.c.internal_timestamp,
                        self.mb.cms_inf_snapshot.c.central_id
                        ]).where(self.mb.cms_inf_snapshot.c.application_id == self.id)
                        
        result = []
        
        for line in self.mb._execute_sqlalchemyquery(query):
            
            result.append(Snapshot(self.mb, line[0], line[1], line[2], line[3], line[4], self, line[5]))

        return result
    
    def __repr__(self):
        return 'Application(name=%s)' % (self.name)

    
class Module:
    """
    The definition of a module
    """
    def __init__(self, mb, identifier, name, uuid, application):
        self.mb = mb
        self.id = identifier
        self.uuid = uuid
        self.name = name
        self.application = application
        
    def __repr__(self):
        return 'Module(name=%s)' % (self.name)


class Package:
    """
    A source code package.
    """
    def __init__(self, identifier, name, path, _type):
        
        self.id = identifier
        self.name = name
        self.path = path
        self.type = _type

    def get_name(self):
        """
        Name of the package
        """
        return self.name
    
    def get_path(self):
        """
        Deployment path of the package
        """
        return self.path
    
    def get_type(self):
        """
        Package type.
        
        :return: 'bo', 'dbudb', 'dbzosextract', 'file', 'formsextract', 
                 'mfextract', 'oracleextract', 'sapextract', 'sqlserverextract',
                 'sybaseextract', 'uiextract'
        """
        return self.type
    
    
    def __repr__(self):
        return 'Package(name=%s, path=%s)' % (self.name, self.path)
    

class AnalysisUnit:
    """
    The definition of an analysis unit.
    """

    def __init__(self, mb, identifier, name, technology, application, log, last_execution_date, uuid):
        self.mb = mb
        self.id = identifier
        self.uuid = uuid
        self.name = name
        self.technology = technology
        self.application = application
        self.local_id_setnam = None
        self.log = log
        self.last_execution_date = last_execution_date

    def get_technology(self):
        """
        Access to technology of the AU.
        
        :return: 'asp', 'bo', 'cobol', 'cpp', 'forms', 'j2ee', 'net', 'ora', 
                 'pb', 'sap', 'sqlsrv', 'syb', 'ua', 'udb', 'ui', 'vb', 'zos'        
        """
        return self.technology
    
    def get_log(self):
        """
        Last analysis log path.
        """
        return self.log
    
    def get_last_execution_date(self):
        """
        Last execution date.
        """
        return self.last_execution_date
    
    def projects(self, kb):
        """
        Given a KnowledgeBase, gives the associated projects
        """
        return self._create_subset_query(kb, 'PRO')

    def heads(self, kb):
        """
        Given a KnowledgeBase, gives the associated head.
        """
        # hmm ... not sure of project restriction
        return self._create_subset_query(kb, 'AU_HEAD').has_type('project')
        
    def full(self, kb):
        """
        Given a KnowledgeBase, gives the associated full content
        """
        return self._create_subset_query(kb, 'AU_FULL')

    def jobs(self, kb):
        """
        Given a KnowledgeBase, gives the job associated with analysis unit.
        
        Probably bugged...
        """
        return self._create_subset_query(kb, 'JOB')

    def _create_subset_query(self, kb, subset_type):
        """
        subset_type in ('PRO', 'AU_HEAD', 'AU_FULL', 'JOB')
        """
        kb._ensure_additional_tables()
        
        # where 
        if kb.get_caip_version() >= StrictVersion("8.2.2"):
            subset_name = 'CMS_' + subset_type + '__' + str(self.uuid)
        else:
            subset_name = 'CMS_' + subset_type + '__' + str(self.id) 
        
        subset_join = outerjoin(kb.pmc_subsets, 
                                kb.pmc_subset_objects, 
                                kb.pmc_subsets.c.subset_id == kb.pmc_subset_objects.c.subset_id)
        subset_content = select([kb.pmc_subset_objects.c.object_id]).select_from(subset_join).where(kb.pmc_subsets.c.subset_name == subset_name)

        result = ObjectQuery(application=kb.get_application(self.application.name))
        result._add_additional_filter(kb.Keys.c.idkey.in_(subset_content))
        result._accept_projects()
        
        return result
        
    def __repr__(self):
        return 'AnalysisUnit(techno=%s, name=%s)' % (self.technology, self.name)


class ModuleContent:
    """
    Content of a module in knowledge base.
    
    """
#     @todo 
#     - move it to knowledge base ?
#     - choose if it is available at some particular steps ?
#     - or always ?
#     

    def __init__(self, application, definition=None, name=None):
        """
        :param application: cast.application.Application
        :param definition: cast.application.managment.Module
        """
        self.application = application
        self.name = None
        self.mngt_uuid = None
        self.mngt_id = None

        if definition:
            
            self.mngt_id = definition.id
            self.mngt_uuid = definition.uuid
            self.name = definition.name
            
            self._calculate_technical_modules()
        
    def get_technical_modules(self):
        """
        Get the technical modules of a module
        """
        if not self.mngt_id:
            raise RuntimeError('module preview is not available')

        return self.technical_modules
    
    def preview(self):
        """
        Access to module content preview as seen from CAST-MS.
        
        Available if module content comes from a ManagmentBase.
        
        Scans table PMC_SUBSET_OBJECTS. The setname comes from the CAST-MS id of the module.
        """
        
        if not self.mngt_id:
            raise RuntimeError('module preview is not available')
        
        kb = self.application.kb
        kb._ensure_additional_tables()
        
        # where 
        if kb.get_caip_version() >= StrictVersion("8.2.2"):
            subset_name = 'CMS_MOD__' + str(self.mngt_uuid) + '_Preparation2'
        else:
            subset_name = 'CMS_MOD__' + str(self.mngt_id) + '_Preparation2'
        
        subset_join = outerjoin(kb.pmc_subsets, 
                                kb.pmc_subset_objects, 
                                kb.pmc_subsets.c.subset_id == kb.pmc_subset_objects.c.subset_id)
        subset_content = select([kb.pmc_subset_objects.c.object_id]).select_from(subset_join).where(kb.pmc_subsets.c.subset_name == subset_name)
        
        result = ObjectQuery(self.application)
        result._add_additional_filter(kb.Keys.c.idkey.in_(subset_content))
        
        return result
    
    def objects(self):
        """
        Access to module content.
        
        APPSET
        """
        kb = self.application.kb
        
        object_filter = union(select([kb.objset.c.idobj]).where(kb.objset.c.idset.in_(self.technical_module_ids)),
                              select([kb.ObjPro.c.idobj]).where(kb.ObjPro.c.idpro.in_(self.technical_module_ids)).where(kb.ObjPro.c.prop == 0))
        
        result = ObjectQuery(self.application)
        result._add_additional_filter(kb.Keys.c.idkey.in_(object_filter))
        
        return result

    def diags(self):
        """
        Access to module content from metrics point of view
        
        Scans table CTT_OBJECT_APPLICATIONS.
        """
        kb = self.application.kb

        object_filter = select([kb.ctt_object_applications.c.object_id]).where(kb.ctt_object_applications.c.application_id.in_(self.technical_module_ids))
        
        result = ObjectQuery(self.application)
        result._add_additional_filter(kb.Keys.c.idkey.in_(object_filter))
        
        return result

    def _get_technical_modules_query(self):
        
        kb = self.application.kb
        kb._ensure_additional_tables()
        
        setname = 'MODULE_JOB_SPA_FROM_PMC#' + self.mngt_uuid
        
        appset_join = outerjoin(kb.appset,
                                kb.setroot,
                                kb.appset.c.idset == kb.setroot.c.idset)
        technical_modules = select([kb.setroot.c.idroot]).select_from(appset_join).where(kb.appset.c.idsetnam == setname)
        
        return technical_modules
    
    def _calculate_technical_modules(self):
        
        kb = self.application.kb
        
        query = self._get_technical_modules_query()
        
        self.technical_module_ids = []
        for line in kb._execute_sqlalchemyquery(query):
            self.technical_module_ids.append(line[0])
        
        query = kb._get_select_object().where(kb.Keys.c.idkey.in_(self.technical_module_ids))
        
        self.technical_modules = list(kb._execute_query(query, self.application))
        
    def __repr__(self):
        
        return 'Module(name=%s)' % self.name


class Snapshot:
    """
    A snapshot.
    """
    
    def __init__(self, mb, identifier, name, version, functional_date, computed_date, application, central_id):
        self.mb = mb
        self.identifier = identifier
        self.name = name
        self.version = version
        self.functional_date = functional_date
        self.computed_date = computed_date # do not work at all... 
        self.application = application
        self.central_id = central_id
        
    
    
    def get_version(self):
        
        return self.version

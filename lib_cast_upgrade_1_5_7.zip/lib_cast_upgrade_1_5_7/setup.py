'''
Created on 26 janv. 2017

@author: MRO
'''
import os
import sys
import logging
from distutils.version import StrictVersion
import xml.etree.ElementTree as eTree
import configparser
from .internal.p1 import get_message, Logger # @UnresolvedImport
from collections import namedtuple


class CASTAIP:
    """
    An install for CAIP.
    """
    def __init__(self, path):
        
        # location
        self.__path = path
        
        # deduced...
        self.__version = None
        self.__user_folder = None
        self.__all_users_path = None
        self.__current_user_temp_path = None
        self.__common_path = None
        self.__common_unversionned_path = None
        self.__plugin_root_path = None
        
        self.__read_cwbin()
        self.__read_ini()
        
        # @todo set the default values
        self.__lisa_path = None
        self.__ltsa_path = None
        self.__log_root_path = None
        
        self.__mail_host = None
        self.__mail_port = None
        self.__mail_from = None
        
        self.__mail_user = None
        self.__mail_password = None
        
        self.__read_cms_preferences()

    @staticmethod
    def get_running_caip():
        """
        Get the current CAIP running.
        """
        # the running python.exe indicates the flat location
        python_exe_path = sys.executable
        return CASTAIP(os.path.dirname(os.path.dirname(os.path.dirname(python_exe_path))))

    def get_version(self):
        """
        Version of the flat.
        """
        return self.__version

    def get_user_preferences_path(self):
        """
        Folder used to store preferences
        
        CAST_CURRENT_USER_WORK_PATH=%APPDATA%\\CAST\\CAST\\$CAST_MAJOR_VERSION$.$CAST_MINOR_VERSION$
        """
        return self.__user_folder
    
    def get_lisa_path(self):
        """
        Access to configured LISA path
        """
        return self.__lisa_path
    
    def get_mail_server(self):
        """
        Returns an SMTP mail server if it has been configured in CMS.
        
        :returns: smtplib.SMTP
        """
        if self.__mail_host:
            
            import smtplib
            
            result = smtplib.SMTP(self.__mail_host, port=self.__mail_port)
            
            try:
                if self.__mail_user:
                    result.starttls()
                    result.login(self.__mail_user, self.__mail_password)
            except:
                logging.warning('Cannot login to mail server')
                raise
                
            return result
    
    def get_mail_from_address(self):
        """
        Get the address specified as the sender for automatic mail.
        """
        return self.__mail_from
    
    def get_all_users_path(self):
        """
        see CastGlobalSettings.ini
        - CAST_ALL_USERS_PATH=%ALLUSERSPROFILE%\Application Data\CAST\CAST\$CAST_MAJOR_VERSION$.$CAST_MINOR_VERSION$
        """
        return self.__all_users_path
    
    def __ensure_servman_connection_profile(self, server):
        """
        @inprogress
        
        Ensure that we have a servman connection profile to engine.

        @deprecated ? 
        @see : https://confluence.castsoftware.com/display/PTKB72/Server+Manager+-+Information+-+Connection+Profile+Path+and+file
        """
        engine = server.engine
        
        dialect = engine.dialect.name
        
        if dialect != "postgresql":
            raise RuntimeError("Not implemented")
        # too bad guys...
        
        appdata = self.get_all_users_path()
        
        if not os.path.exists(appdata):
            os.makedirs(appdata)

        profile_name = self.__get_profile_name(engine)
        
        servman_profile_path = os.path.join(appdata, "CWSIProfileConnection.INI")
        available = False
        
        with open(servman_profile_path, 'r') as servman_profile:
            # search [profile_name]
            for line in servman_profile.readlines():
                if ('[' + profile_name + ']') in line:
                    available = True
        
        if not available:
            servman_profile_write = open(servman_profile_path, 'a')
            servman_profile_write.write("""[%s]
1=slocalhost:2280
3=s%s
2=s%s:%s
54=i1
41=i22
39=b0
55=sLIBPQ:%s:%s
13=i4
8=i303
9=i303
10=b1
38=s%s
""" % (profile_name, engine.url.username, engine.url.host, engine.url.port, engine.url.host, engine.url.port, Logger().set_message(engine.url.password)))
    
    
    def __read_cms_preferences(self):
        """
        cast-ms.preferences.pmx
        """
        tree = eTree.parse(os.path.join(self.__user_folder, 'cast-ms.preferences.pmx'))
        root = tree.getroot()
        
        lot = next(iter(root))
        
        for preference in lot:
            
            if preference.tag == 'preferences.Preferences':
                
                try:
                    self.__lisa_path = preference.attrib['workingPath']
                except:
                    pass

                try:
                    self.__ltsa_path = preference.attrib['temporaryPath']
                except:
                    pass

                try:
                    self.__log_root_path = preference.attrib['logRootPath']
                except:
                    pass

            else:
                try:
                    self.__mail_host = preference.attrib['host']
                except:
                    pass
        
                try:
                    self.__mail_port = preference.attrib['port']
                except:
                    pass
        
                try:
                    self.__mail_from = preference.attrib['from']
                except:
                    pass
                
                for credential in preference:
                    for credential_preference in credential:
                        
                        try:
                            self.__mail_user = credential_preference.attrib['user']
                        except:
                            pass

                        try:
                            self.__mail_password = get_message(credential_preference.attrib['password'][9:])
                        except:
                            pass
                        
        
    def __read_cwbin(self):
        """
        Extract version from cw.bin
        """
        with open(os.path.join(self.__path, 'cw.bin'), "rb") as cwbin:
            
            versionString = ''
            fileBytes = cwbin.read()
            index = 18
            while True:
                
                current = chr(fileBytes[index]-100)
                if str.isdigit(current) or current == '.':
                    versionString += current;
                else:
                    break
                index += 1
            
            self.__version = StrictVersion(versionString)
            
            
    def __read_ini(self):
        """
        Read CastGlobalSettings.ini to get some variables
        """
        
        values = {'CAST_CURRENT_USER_WORK_PATH':'%APPDATA%\\CAST\\CAST\\$CAST_MAJOR_VERSION$.$CAST_MINOR_VERSION$\\',
                  'CAST_ALL_USERS_PATH':r'%ALLUSERSPROFILE%\Application Data\CAST\CAST\$CAST_MAJOR_VERSION$.$CAST_MINOR_VERSION$',
                  'CAST_CURRENT_USER_TEMP_PATH':r'%TEMP%\CAST\CAST\$CAST_MAJOR_VERSION$.$CAST_MINOR_VERSION$',
                  'CAST_PROGRAM_FILES_COMMON_PATH':r'%CommonProgramFiles%\CAST\CAST\$CAST_MAJOR_VERSION$.$CAST_MINOR_VERSION$',
                  'CAST_PROGRAM_FILES_COMMON_UNVERSIONED_PATH':r'%CommonProgramFiles%\CAST\CAST',
                  'CAST_PLUGINS_ROOT_PATH':r'%ALLUSERSPROFILE%\Application Data\CAST\CAST\Extensions'
                  }
        
        with open(os.path.join(self.__path, 'CastGlobalSettings.ini')) as settings:
            
            for line in settings:
                
                if not line.startswith('CAST_'):
                    continue
                value = line[line.find('=')+1:].strip()

                if line.startswith('CAST_CURRENT_USER_WORK_PATH'):
                    values['CAST_CURRENT_USER_WORK_PATH'] = value           

                if line.startswith('CAST_ALL_USERS_PATH'):
                    values['CAST_ALL_USERS_PATH'] = value           

                if line.startswith('CAST_CURRENT_USER_TEMP_PATH'):
                    values['CAST_CURRENT_USER_TEMP_PATH'] = value           

                if line.startswith('CAST_PROGRAM_FILES_COMMON_PATH'):
                    values['CAST_PROGRAM_FILES_COMMON_PATH'] = value           

                if line.startswith('CAST_PROGRAM_FILES_COMMON_UNVERSIONED_PATH'):
                    values['CAST_PROGRAM_FILES_COMMON_UNVERSIONED_PATH'] = value           

                if line.startswith('CAST_PLUGINS_ROOT_PATH'):
                    values['CAST_PLUGINS_ROOT_PATH'] = value           


        
        def expand(text):
        
            text = text.replace('$CAST_MAJOR_VERSION$', str(self.__version.version[0]))
            text = text.replace('$CAST_MINOR_VERSION$', str(self.__version.version[1]))
            text = os.path.expandvars(text)
            return text
            
        self.__user_folder = expand(values['CAST_CURRENT_USER_WORK_PATH'])
        self.__all_users_path = expand(values['CAST_ALL_USERS_PATH'])

        self.__current_user_temp_path = expand(values['CAST_CURRENT_USER_TEMP_PATH'])
        self.__common_path = expand(values['CAST_PROGRAM_FILES_COMMON_PATH'])
        self.__common_unversionned_path = expand(values['CAST_PROGRAM_FILES_COMMON_UNVERSIONED_PATH'])
        self.__plugin_root_path = expand(values['CAST_PLUGINS_ROOT_PATH'])
        
    @staticmethod
    def __get_profile_name(engine):
    
        return "%s:%s" % (engine.url.host, engine.url.port)
        
    def __repr__(self):
        
        return 'CAIP(%s, %s)' % (self.__path, self.__version)
        
        
def read_enlighten_connection_profiles(path):
    """
    Read a CWProfileConnection.INI to extract the connection informations
    
    returns a list of tuple : engine, schema name
    :param path: path of the file to read
    
    For now: postgresql only 
    """
    
    from . import create_postgres_engine
    
    config = configparser.ConfigParser()
    config.read(path)
    
    result = []
    
    for section in config.sections():

        connection_string = config.get(section, '55')[1:]
        if not connection_string.startswith('LIBPQ'):
            continue
        
        server_port = connection_string.split(',')[0].split(':')[1:]
        
        if len(server_port) == 2:
            server, port = server_port
        elif len(server_port) == 1:
            server = server_port[0]
            port = 2280 # not sure here 
        
        user = config.get(section, '3')[1:]
        cp = config.get(section, '38')[1:]
        password = Logger().get_message(cp)
        schema = config.get(section, '27')[1:]
        result.append((create_postgres_engine(host=server, port=int(port), user=user, password=password), schema))

    return result

def read_servman_connection_profiles(path):
    """
    Read a CWSIProfileConnection.INI to extract the connection informations
    
    returns a list of engine
    :param path: path of the file to read
    
    For now: postgresql only
    """
    
    from . import create_postgres_engine
    
    config = configparser.ConfigParser()
    config.read(path)
    
    result = []
    
    for section in config.sections():

        connection_string = config.get(section, '55')[1:]
        if not connection_string.startswith('LIBPQ'):
            continue
        
        server, port = connection_string.split(',')[0].split(':')[1:]
        
        user = config.get(section, '3')[1:]
        cp = config.get(section, '38')[1:]
        password = Logger().get_message(cp)
#         print(server, port, user, password)
        result.append(create_postgres_engine(host=server, port=int(port), user=user, password=password))

    return result
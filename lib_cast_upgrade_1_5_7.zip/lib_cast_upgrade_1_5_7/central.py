from sqlalchemy import select
from . import CastSchema
from .internal.reflect import reflect_table 


class CentralBase(CastSchema):
    """
    A connection to a central base
    """
    
    def __init__(self, name, engine=None):
        
        CastSchema.__init__(self, name, engine)
        self._package_name = "ADG_CENTRAL"
        
        self.dss_objects = reflect_table('DSS_OBJECTS', self.metadata, self.engine)
        self.dss_object_info = reflect_table('DSS_OBJECT_INFO', self.metadata, self.engine)
        self.dss_translation = reflect_table('DSS_TRANSLATION_TABLE', self.metadata, self.engine)
        self.dss_snapshots = reflect_table('DSS_SNAPSHOTS', self.metadata, self.engine)
    
    def __repr__(self):
        return 'CentralBase(%s)' % self.name
    
    def get_snapshots(self):
        """
        Access to snapshots.
        
        @return: .Snapshot
        """
        
        query = select([self.dss_snapshots.c.snapshot_id, 
                        self.dss_snapshots.c.application_id,
                        self.dss_snapshots.c.snapshot_name])
    
        result = []
    
        for line in self._execute_sqlalchemyquery(query):
            
            result.append(Snapshot(line[0], line[2], line[1]))
    
        return result
    

class Snapshot:
    
    def __init__(self, identifier, name, application_id):
        
        self.name = name
        self.id = identifier
            
    